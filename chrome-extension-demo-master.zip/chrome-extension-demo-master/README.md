This repo is the demo for Dan Shultz's tutorial ["Creating A Basic Chrome Extension"](https://www.thepolyglotdeveloper.com/2018/09/creating-basic-chrome-extension/). I fixed some typos in his code.
